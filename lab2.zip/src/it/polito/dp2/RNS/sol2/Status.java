package it.polito.dp2.RNS.sol2;

public enum Status {
	LOADED,NOT_LOADED;
}
